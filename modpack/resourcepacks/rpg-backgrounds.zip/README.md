# Pixel-RPG-icons
A collection of public domain icons packaged as a Minecraft resource pack
